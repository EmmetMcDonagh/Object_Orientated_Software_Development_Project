
package ie.gmit.dip;

public class Runner {
	
	//The required main() method to run the application is defined inside a class called Runner.java. 

	public static void main(String[] args) {
		Menu m = new Menu();
		m.start();

	}
}
